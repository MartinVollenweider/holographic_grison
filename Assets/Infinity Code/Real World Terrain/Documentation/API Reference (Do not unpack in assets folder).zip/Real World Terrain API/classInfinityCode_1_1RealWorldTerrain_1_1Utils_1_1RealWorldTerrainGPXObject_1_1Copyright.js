var classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1Copyright =
[
    [ "Copyright", "classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1Copyright.html#a33b25f979690b78772b8f3a20bef20ab", null ],
    [ "Copyright", "classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1Copyright.html#a3600dec641b6178a13850d6f102bb2af", null ],
    [ "author", "classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1Copyright.html#a097707cb9ea434c814c35339445e627c", null ],
    [ "license", "classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1Copyright.html#a9d71da0e90917b8bd141714f7fccf7b8", null ],
    [ "year", "classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1Copyright.html#a4e1bfaf30319b2cc75e226043bdf0e59", null ]
];