var classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams =
[
    [ "TextParams", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#a2226d2cbadf2a34b357799c526ff3eda", null ],
    [ "language", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#a50de3a87b28dbcef653016468496883e", null ],
    [ "latitude", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#a9aec5d581873ad4b63b411d7f165bd13", null ],
    [ "longitude", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#ad15695945da7dbb4b61224976b2f1b04", null ],
    [ "maxprice", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#a40c382bd9687354c6e01804a0fc732c4", null ],
    [ "minprice", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#a00ecef4defe83f672dd716ae0d5f3968", null ],
    [ "opennow", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#a500dfe6498dc79ed424f17be3aae9699", null ],
    [ "pagetoken", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#a7a7515e38fde5cbe0e6f7a2c98484175", null ],
    [ "query", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#ae190f875deb7092452b39e1a6ee7f1c0", null ],
    [ "radius", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#ae7c0f5f6d306d82f3b4f6f40ca360c50", null ],
    [ "types", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#a93bd19ba1ceecba4c7c487826ffdad50", null ],
    [ "zagatselected", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#ad2228804d76355330b1f304d05e3d78a", null ],
    [ "lnglat", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html#aae2da709be4564a1146821635bb99885", null ]
];