var classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOI =
[
    [ "RealWorldTerrainPOI", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOI.html#a1ca3bf7e3dc32a1e0d0658ea05604781", null ],
    [ "title", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOI.html#a8cfe0e505995143cf62d781ef8eb9d56", null ],
    [ "x", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOI.html#abe4a56783e5acf92ff3f1e021bb448d2", null ],
    [ "y", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOI.html#a58278ff8ecd976d08d8667dc369fe248", null ]
];