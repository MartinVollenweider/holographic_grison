var classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOIItem =
[
    [ "SetPrefs", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOIItem.html#ac831d134ddc18e85e2f2531cb6b473ae", null ],
    [ "title", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOIItem.html#a2bc36c16fde84ff10d896f0e9b58e391", null ],
    [ "x", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOIItem.html#a5bf0f9f17a2643d568c5280c4bc451a4", null ],
    [ "y", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOIItem.html#a957a947cb723d0bf7fa7b2f1b4c57252", null ]
];