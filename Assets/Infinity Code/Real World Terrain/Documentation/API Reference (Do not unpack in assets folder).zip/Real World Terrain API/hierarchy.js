var hierarchy =
[
    [ "InfinityCode.RealWorldTerrain.Webservices.Results.RealWorldTerrainGoogleGeocodingResult.AddressComponent", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1Results_1_1RealWorldTerrainGoogleGeocodingResult_1_1AddressComponent.html", null ],
    [ "InfinityCode.RealWorldTerrain.Utils.RealWorldTerrainGPXObject.Bounds", "classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1Bounds.html", null ],
    [ "InfinityCode.RealWorldTerrain.Utils.RealWorldTerrainGPXObject.Copyright", "classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1Copyright.html", null ],
    [ "InfinityCode.RealWorldTerrain.Utils.RealWorldTerrainGPXObject.EMail", "classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1EMail.html", null ],
    [ "InfinityCode.RealWorldTerrain.RealWorldTerrainTextureProviderManager.IExtraField", "interfaceInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainTextureProviderManager_1_1IExtraField.html", [
      [ "InfinityCode.RealWorldTerrain.RealWorldTerrainTextureProviderManager.ExtraField", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainTextureProviderManager_1_1ExtraField.html", null ],
      [ "InfinityCode.RealWorldTerrain.RealWorldTerrainTextureProviderManager.ToggleExtraGroup", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainTextureProviderManager_1_1ToggleExtraGroup.html", null ]
    ] ],
    [ "InfinityCode.RealWorldTerrain.Utils.RealWorldTerrainGPXObject.Link", "classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1Link.html", null ],
    [ "InfinityCode.RealWorldTerrain.RealWorldTerrainTextureProviderManager.MapType", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainTextureProviderManager_1_1MapType.html", null ],
    [ "InfinityCode.RealWorldTerrain.Utils.RealWorldTerrainGPXObject.Meta", "classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1Meta.html", null ],
    [ "InfinityCode.RealWorldTerrain.Utils.RealWorldTerrainGPXObject.Person", "classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1Person.html", null ],
    [ "InfinityCode.RealWorldTerrain.Webservices.Results.RealWorldTerrainPlacesResult.Photo", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1Results_1_1RealWorldTerrainPlacesResult_1_1Photo.html", null ],
    [ "InfinityCode.RealWorldTerrain.RealWorldTerrainBuilding", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuilding.html", null ],
    [ "InfinityCode.RealWorldTerrain.RealWorldTerrainBuildingMaterial", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuildingMaterial.html", null ],
    [ "InfinityCode.RealWorldTerrain.RealWorldTerrainBuildRBuilding", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuildRBuilding.html", null ],
    [ "InfinityCode.RealWorldTerrain.RealWorldTerrainBuildRPresetsItem", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuildRPresetsItem.html", null ],
    [ "InfinityCode.RealWorldTerrain.ExtraTypes.RealWorldTerrainGeoRect", "classInfinityCode_1_1RealWorldTerrain_1_1ExtraTypes_1_1RealWorldTerrainGeoRect.html", null ],
    [ "InfinityCode.RealWorldTerrain.Webservices.Results.RealWorldTerrainGoogleGeocodingResult", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1Results_1_1RealWorldTerrainGoogleGeocodingResult.html", null ],
    [ "InfinityCode.RealWorldTerrain.Webservices.Results.RealWorldTerrainGooglePlaceDetailsResult", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1Results_1_1RealWorldTerrainGooglePlaceDetailsResult.html", null ],
    [ "InfinityCode.RealWorldTerrain.Utils.RealWorldTerrainGPXObject", "classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject.html", null ],
    [ "InfinityCode.RealWorldTerrain.RealWorldTerrainMonoBase", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainMonoBase.html", [
      [ "InfinityCode.RealWorldTerrain.RealWorldTerrainContainer", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainContainer.html", null ],
      [ "InfinityCode.RealWorldTerrain.RealWorldTerrainItem", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainItem.html", null ]
    ] ],
    [ "InfinityCode.RealWorldTerrain.OSM.RealWorldTerrainOSMBase", "classInfinityCode_1_1RealWorldTerrain_1_1OSM_1_1RealWorldTerrainOSMBase.html", [
      [ "InfinityCode.RealWorldTerrain.OSM.RealWorldTerrainOSMNode", "classInfinityCode_1_1RealWorldTerrain_1_1OSM_1_1RealWorldTerrainOSMNode.html", null ],
      [ "InfinityCode.RealWorldTerrain.OSM.RealWorldTerrainOSMRelation", "classInfinityCode_1_1RealWorldTerrain_1_1OSM_1_1RealWorldTerrainOSMRelation.html", null ],
      [ "InfinityCode.RealWorldTerrain.OSM.RealWorldTerrainOSMWay", "classInfinityCode_1_1RealWorldTerrain_1_1OSM_1_1RealWorldTerrainOSMWay.html", null ]
    ] ],
    [ "InfinityCode.RealWorldTerrain.OSM.RealWorldTerrainOSMMeta", "classInfinityCode_1_1RealWorldTerrain_1_1OSM_1_1RealWorldTerrainOSMMeta.html", null ],
    [ "InfinityCode.RealWorldTerrain.OSM.RealWorldTerrainOSMMetaTag", "classInfinityCode_1_1RealWorldTerrain_1_1OSM_1_1RealWorldTerrainOSMMetaTag.html", null ],
    [ "InfinityCode.RealWorldTerrain.OSM.RealWorldTerrainOSMRelationMember", "classInfinityCode_1_1RealWorldTerrain_1_1OSM_1_1RealWorldTerrainOSMRelationMember.html", null ],
    [ "InfinityCode.RealWorldTerrain.OSM.RealWorldTerrainOSMTag", "classInfinityCode_1_1RealWorldTerrain_1_1OSM_1_1RealWorldTerrainOSMTag.html", null ],
    [ "InfinityCode.RealWorldTerrain.Webservices.Results.RealWorldTerrainPlacesResult", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1Results_1_1RealWorldTerrainPlacesResult.html", null ],
    [ "InfinityCode.RealWorldTerrain.RealWorldTerrainPOI", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOI.html", null ],
    [ "InfinityCode.RealWorldTerrain.RealWorldTerrainPOIItem", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPOIItem.html", null ],
    [ "InfinityCode.RealWorldTerrain.RealWorldTerrainPrefsBase", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainPrefsBase.html", null ],
    [ "InfinityCode.RealWorldTerrain.RealWorldTerrainRangeI", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainRangeI.html", null ],
    [ "InfinityCode.RealWorldTerrain.Utils.RealWorldTerrainReflectionHelper", "classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainReflectionHelper.html", null ],
    [ "InfinityCode.RealWorldTerrain.RealWorldTerrainUtils", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainUtils.html", null ],
    [ "InfinityCode.RealWorldTerrain.RealWorldTerrainVector2i", "structInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainVector2i.html", null ],
    [ "InfinityCode.RealWorldTerrain.Webservices.RealWorldTerrainWebServiceBase", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainWebServiceBase.html", [
      [ "InfinityCode.RealWorldTerrain.Webservices.Base.RealWorldTerrainTextWebServiceBase", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1Base_1_1RealWorldTerrainTextWebServiceBase.html", [
        [ "InfinityCode.RealWorldTerrain.Webservices.RealWorldTerrainGoogleGeocoding", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGoogleGeocoding.html", null ],
        [ "InfinityCode.RealWorldTerrain.Webservices.RealWorldTerrainGooglePlaceDetails", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaceDetails.html", null ],
        [ "InfinityCode.RealWorldTerrain.Webservices.RealWorldTerrainGooglePlaces", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces.html", null ]
      ] ],
      [ "InfinityCode.RealWorldTerrain.Webservices.RealWorldTerrainGooglePlacePhoto", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlacePhoto.html", null ]
    ] ],
    [ "InfinityCode.RealWorldTerrain.ExtraTypes.RealWorldTerrainWWW", "classInfinityCode_1_1RealWorldTerrain_1_1ExtraTypes_1_1RealWorldTerrainWWW.html", null ],
    [ "InfinityCode.RealWorldTerrain.XML.RealWorldTerrainXML", "classInfinityCode_1_1RealWorldTerrain_1_1XML_1_1RealWorldTerrainXML.html", null ],
    [ "InfinityCode.RealWorldTerrain.XML.RealWorldTerrainXMLList", "classInfinityCode_1_1RealWorldTerrain_1_1XML_1_1RealWorldTerrainXMLList.html", null ],
    [ "InfinityCode.RealWorldTerrain.Webservices.RealWorldTerrainGooglePlaces.RequestParams", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1RequestParams.html", [
      [ "InfinityCode.RealWorldTerrain.Webservices.RealWorldTerrainGooglePlaces.NearbyParams", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1NearbyParams.html", null ],
      [ "InfinityCode.RealWorldTerrain.Webservices.RealWorldTerrainGooglePlaces.RadarParams", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1RadarParams.html", null ],
      [ "InfinityCode.RealWorldTerrain.Webservices.RealWorldTerrainGooglePlaces.TextParams", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGooglePlaces_1_1TextParams.html", null ]
    ] ],
    [ "InfinityCode.RealWorldTerrain.Webservices.RealWorldTerrainGoogleGeocoding.RequestParams", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGoogleGeocoding_1_1RequestParams.html", [
      [ "InfinityCode.RealWorldTerrain.Webservices.RealWorldTerrainGoogleGeocoding.GeocodingParams", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGoogleGeocoding_1_1GeocodingParams.html", null ],
      [ "InfinityCode.RealWorldTerrain.Webservices.RealWorldTerrainGoogleGeocoding.ReverseGeocodingParams", "classInfinityCode_1_1RealWorldTerrain_1_1Webservices_1_1RealWorldTerrainGoogleGeocoding_1_1ReverseGeocodingParams.html", null ]
    ] ],
    [ "InfinityCode.RealWorldTerrain.Utils.RealWorldTerrainGPXObject.Route", "classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1Route.html", null ],
    [ "InfinityCode.RealWorldTerrain.Utils.RealWorldTerrainGPXObject.Track", "classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1Track.html", null ],
    [ "InfinityCode.RealWorldTerrain.Utils.RealWorldTerrainGPXObject.TrackSegment", "classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1TrackSegment.html", null ],
    [ "InfinityCode.RealWorldTerrain.Utils.RealWorldTerrainGPXObject.Waypoint", "classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1Waypoint.html", null ]
];