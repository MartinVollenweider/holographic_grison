var searchData=
[
  ['waypoint',['Waypoint',['../classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1Waypoint.html#a0cc0e38c760349e7b87267ffb9fa6982',1,'InfinityCode.RealWorldTerrain.Utils.RealWorldTerrainGPXObject.Waypoint.Waypoint(double lon, double lat)'],['../classInfinityCode_1_1RealWorldTerrain_1_1Utils_1_1RealWorldTerrainGPXObject_1_1Waypoint.html#a7b779aae8faf944da765db6764fa9895',1,'InfinityCode.RealWorldTerrain.Utils.RealWorldTerrainGPXObject.Waypoint.Waypoint(RealWorldTerrainXML node)']]]
];
